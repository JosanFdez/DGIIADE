#include <iostream>
#include <fstream>
#include <set>
#include <cstdlib>
#include <vector>

using namespace std;

set<pair<int,string>, greater<>> contenedores;

bool leerFichero(const char *nombrefich) {
    ifstream fich;
    fich.open(nombrefich);
    if (!fich) return false;

    pair<int,string> contenedor;

    int peso;
    string nombre;

    int tam;
    fich >> tam;

    for (int i = 0; i < tam; i++){
        fich >> nombre;
        contenedor.second = nombre;
        fich >> peso;
        contenedor.first = peso;
        contenedores.insert(contenedor);
    };

    return true;
}



// Metemos el primero (mas pequeño),

void pesoMaximo(int limite) {

    vector<pair<int, string>> selec;
    int acumulado = 0;
    bool justo = false;

    int aux;

    for (auto it = contenedores.begin(); !justo && it != contenedores.end(); it++) {
        if (acumulado + (*it).first <= limite){
            cout << (*it).second << " " << (*it).first << endl;
            acumulado += (*it).first;
            if (acumulado == limite) justo = true;
        }
    }

    if (justo)
        cout << "La solución es óptima" << endl;
    else
        cout << "La solución no es óptima. Se han rellenado " << acumulado << "/" << limite << endl;
    
}

int main (int argc, char *argv[]) {

    if(!leerFichero(argv[1])){
        cout << "Lectura Incorrecta" << endl;
        return 1;
    }

    cout << "Carga máxima del barco: " << atoi(argv[2]);

    cout << endl;

    cout << "Solución: " << endl;
    pesoMaximo(atoi(argv[2]));

}