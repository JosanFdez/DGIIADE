#include <iostream>
#include <queue>
#include <vector>
#include <stack>
#include <fstream>

using namespace std;

static const int INF = 1000000;                                    // Valor por defecto de los pesos

struct node {
    int nodeID;                                         // Nodo representado en el algoritmo de Dijkstra
    int acum;
    int prevID;
    node(){
        nodeID= -1;
        acum = 0;
        prevID = -1;
    }
};

struct compare {                                        // La STL implementa un Max-Heap, queremos un Min-Heap para devolver el nodo con "acum" menor
    bool operator()(const node & a, const node & b){
        if (a.acum == b.acum)
            return a.acum;
        else
            return a.acum > b.acum;                     //Ahora sí podemos devolver aquel nodo que tenga la acumulada menor
    }
};

class Dijkstra {
private:

    // NÚMERO DE NODOS Y MATRICES DINÁMICAS QUE REPRESENTAN EL GRAFO

    int n=0;                                  // Número de nodos
    pair<string,bool> *nodos;               // Nombres de los nodos del grafo (Índice en el vector asignado para cada nodo. El nodo n tendrá índice n-1)
    // Para cada nodo, el booleano indica si el nodo ya se ha marcado o no como permanente
    int **pesos;                            // M. de adyacencia de los pesos de cada arista (fila = nodo origen, columna = nodo destino)

    // ESTRUCTURAS DE DATOS PRIVADAS DERIVADOS DE LA RESOLUCIÓN

    priority_queue<node,vector<node>, compare> tempNodes;       // Cola para ordenar los nodos temporales
    //stack<node> permNodes;                                      // Cola para los nodos con etiquetas permanentres


    pair<node,bool> **resolucion;                               //Tabla en la que iremos anotando los pasos de resolver el problema
    //Contendrá el nodo, con la información respectiva y un bool que indicará si es permanente o no

    void Reservar(int numNodos){
        if (n > 0){
            Liberar();
        }

        n = numNodos;

        // RESERVA DE MEMORIA

        nodos = new pair<string,bool>[n];
        pesos = new int*[n];
        resolucion = new pair<node,bool>*[n];

        for (int i = 0; i < n; i++) {
            pesos[i] = new int[n];
            resolucion[i] = new pair<node,bool>[n];
        }

        // INICIALIZACIÓN

        for (int i = 0; i < n; i++){
            nodos[i].second = false;
            for (int j = 0; j < n; j++){
                pesos[i][j] = INF;
                resolucion[i][j].second = false;
            }
        }

    }

    void Liberar() {
        if (n > 0) {
            for (int i = 0; i < n; i++) {
                delete [] pesos[i];
                delete [] resolucion[i];
            }

            delete [] nodos;
            delete [] pesos;
            delete [] resolucion;

            n=0;
            nodos = nullptr;
            pesos = nullptr;
            resolucion = nullptr;
        }                                          // Liberamos matrices de aristas y pesos
    }

public:

    bool leerFichero(const char *nombrefich) {

        Liberar();

        ifstream fich;

        int numNodos;
        int numPeso;
        string nombreAux;

        fich.open(nombrefich);
        if (!fich)
            return false;

        fich >> numNodos;

        Reservar(numNodos);

        for (int i = 0; i < numNodos; i++){
            fich >> nombreAux;
            nodos[i].first = nombreAux;
        }

        for (int i = 0; i < numNodos; i++){
            for (int j = 0; j < numNodos; j++){
                fich >> numPeso;
                if (numPeso > -1)                                           // si no se pone nada, se queda en INF
                    pesos[i][j] = numPeso;
            }
        }

        cout << "Se han leído un total de " << numNodos << " nodos" << endl;
        fich.close();
        return true;
    }

    void imprimirMatriz (){
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                cout << pesos[i][j] << "\t\t";
            }
            cout << endl;
        }
    }

    void imprimirResolucion(){
        node print;
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){
                print = resolucion[i][j].first;
                if (print.nodeID != -1){
                    if (print.acum == -2) cout << "*";
                    else cout << "(" << print.acum << "," << print.prevID << ")";
                    if (resolucion[i][j].second) cout << "!";
                    cout << "\t\t\t";
                } else{
                    cout << "NodoVacio\t\t";
                }
            }
            cout << endl;
        }
    }

    /**
     * @brief Calcula el camíno mínimo entre dos nodos especificados por sus ID numéricas
     *
     * @param origID ID numérica del nodo origen del que queremos partir
     * @param destID ID numérica del nodo destino al que queremos llegar
     * @pre 0 <= origID, destID, <= n-1
     * @return La distancia mínima entre ambos nodos origen y destino
     */
    void MinimoCamino(int origID){

        node nodoAsterisco; // Cuando marquemos un nodo como permanente, toda su fila en la matriz resolucion se rellena con asterisco para poder ignorarlo en futuros pasos
        nodoAsterisco.acum = -2;  // identificaremos a un nodo asterisco como aquel que tiene acum -2. tendrá el paso (j) en el que dicho nodo permanente se originó
        // en el parámetro prev (para luego poder saltar rápidamente) y conservará el nodeID al que se refiere

        // Inicializamos con nodo origen (origID,0,nullptr)

        node currNode, pivot;
        pivot.nodeID = origID;                              // pivot será el nodo sobre el que estamos pivotando en cada iteración (el último permanente)
        nodos[origID].second = true;
        // resolucion[origID][0].first = pivot;
        // resolucion[origID][0].second = true;

        for (int j = 0; j < n; j++){ // j es paso en el que estamos.

            // En el nuevo paso, aquel nodo que se nos marque como pivote, será marcado como permanente. Nos ayudamos del nodo pivot (nodeID será la fila y j el paso)

            resolucion[pivot.nodeID][j].first = pivot;          // Metemos el pivote en la casilla correspondiente
            resolucion[pivot.nodeID][j].second = true;          // Lo marcamos como permanente

            nodoAsterisco.prevID = j;
            nodoAsterisco.nodeID = pivot.nodeID;
            for (int k = j+1; k < n; k++) {
                resolucion[pivot.nodeID][k].first = nodoAsterisco;            // Rellenamos con el nodo asterisco
            }


            // METEMOS LOS NODOS QUE CUMPLAN LAS CONDICIONES EN LA COLUMNA DEL NUEVO PASO

            for (int i = 0; i < n; i++){ // i, dentro de cada paso, será el ID del nodo en el que estaremos comprobando conexion en cada iteracion

                // Obtenemos currNode

                if (resolucion[i][j].first.acum != -2){                          // Si no es nodo asterisco

                    currNode.nodeID = i;                                            // Fila en la que estamos
                    currNode.acum = pivot.acum + pesos[pivot.nodeID][i];            // acum del pivote + la nueva arista que conecta el pivote con el nodo nuevo
                    currNode.prevID = pivot.nodeID;                                 // nodo pivote al que va conectado el nodo actual


                    // Vemos si metemos currNode o el elemento que estaba antes para ese nodo

                    if (pesos[pivot.nodeID][i] != INF && !nodos[i].second){     // Si la arista existe y no se ha usado aún lo metemos
                        resolucion[i][j].first = currNode;
                        tempNodes.push(currNode);
                        nodos[i].second = true;                                         // Lo marcamos como usado

                    } else if (nodos[i].second) {                               // Si ya se ha usado
                        if (j-1 >= 0 && !resolucion[i][j].second) {             // Si no se sale de la matriz (en j = 0, se sale) y no es permanente
                            resolucion[i][j] = resolucion[i][j-1];                      // Copiamos el anterior pero no metemos en candidatos, exista o no la arista luego comprobamos
                            tempNodes.push(resolucion[i][j].first);
                        }
                        if (pesos[pivot.nodeID][i] != INF) {                                // Si la arista existe
                            if (currNode.acum < resolucion[i][j-1].first.acum){             // Si el elemento que vamos a insertar es menor lo reemplazamos
                                resolucion[i][j].first = currNode;
                                tempNodes.push(currNode);                                   // Metemos en candidatos posibles
                            }                                                               // Si es mayor o igual, dejamos el que está
                        }                                                                   // Si la arista no existe no hacemos nada (ya insertamos el elemento antes)
                    }
                }
            }

            // Nunca reemplazaremos el nodo iterador ya que nunca tendrá una arista consigo mismo.

            // Dejamos el nodo iterador en sus valores por defecto

            currNode.nodeID = -1;
            currNode.acum = 0;
            currNode.prevID = -1;

            // DECIDIMOS CUAL DE LOS NODOS INTRODUCIDOS SERÁ EL SIGUIENTE PIVOTE (Y POSTERIOR PERMANENTE)

            // Para decidir qué casilla marcaremos como siguiente pivote sacamos la casilla que hayamos metido con el acum menor y la marcamos como pivote.

            pivot = tempNodes.top();

            // Vaciamos tempNodes
            while(!tempNodes.empty()){
                tempNodes.pop();
            }

            cout << "Paso " << j << ":" << endl;
            imprimirResolucion();
            cout << endl;


        }

        // Ya tenemos la tabla hecha, es decir, el camino mínimo desde el nodo origen hasta cada uno de los nodos del grafo. Solo queda especificar el nodo destino

        int destID = -1;

        while (!(destID >= 0 && destID <= n-1)) {
            cout << "Nodo destino: ";
            cin >> destID;
        }

        // Creamos un nodo iterador para poder ir hacia atrás en la tabla y poder imprimir el camino mínimo

        stack<int> camino;                   // Al estar recorriendo la tabla al revés, deberemos de darle la vuelta al camino al terminar. Lo hacemos con dos pilas.

        node iteratorPath = resolucion[destID][n-1].first;

        // Ya que la variable acum de los asteriscos es -2, deberemos irnos al nodo permanente correspondiente para poder saber la suma

        if (iteratorPath.acum == -2){
            iteratorPath = resolucion[iteratorPath.nodeID][iteratorPath.prevID].first;
        }

        cout << "El tiempo mínimo del nodo sensor (" << origID << ") al servidor central (" << destID << ") es de: " << iteratorPath.acum << endl;

        for (int i = n-1; iteratorPath.nodeID != origID && i >= 0;){

            // decrementamos 1 en la fila que indique prevID

            // (Posición prevID anterior) si es asterisco saltamos a donde diga prevID del asterisco

            camino.push(iteratorPath.nodeID);
            iteratorPath = resolucion[iteratorPath.prevID][i-1].first;
            i--;


            if (iteratorPath.acum == -2){
                i = iteratorPath.prevID;
                iteratorPath = resolucion[iteratorPath.nodeID][iteratorPath.prevID].first;
            }
        }

        // Partiendo ahora del nodo destino permanente en la tabla, almacenamos valores y seguimos iterando hacia atrás.

        cout << "El camino pasa, en el orden especificado, por los siguientes nodos: " << origID << " ";

        while (!camino.empty()){
            cout << camino.top() << " ";
            camino.pop();
        }

        cout << endl;
        Liberar();
    }
};

int main (int argc, char *argv[]){

    Dijkstra d;


    if (!d.leerFichero(argv[1])) {
        cout << "Lectura Incorrecta" << endl;
        return 1;
    }

    cout << "Se ha leído la siguiente matriz: " << endl;
    d.imprimirMatriz();

    int origID;
    cout << "Nodo Origen: " << endl;
    cin >> origID;
    d.MinimoCamino(origID);
    return 0;
}