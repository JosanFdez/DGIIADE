#include <iostream>
#include <fstream>
#include <set>

using namespace std;

set<pair<int,string>, greater<pair<int,string>>> distGas;

bool leerFichero(const char *nombrefich) {
    ifstream fich;

    int n;
    int distancia;
    string nombre;
    pair<int,string> gasofla;

    fich.open(nombrefich);
    if (!fich)
        return false;

    fich >> n;

    for (int i = 0; i < n; i++){
        fich >> nombre;
        fich >> distancia;
        gasofla.second = nombre;
        gasofla.first = distancia;
        distGas.insert(gasofla);
    }

    return true;
}

void resolver(int autonomia, int distancia){
    int origen = 0;
    int restante = distancia;
    pair<int,string> aux;
    set<pair<int,string>>::iterator it;
    bool done;

    int contador = 0;

    while (restante > autonomia) {
        done = false;
        for (it = distGas.begin(); it != distGas.end() && !done; it++){
            aux = *it;
            if (aux.first - origen <= autonomia) {
                contador++;
                done = true;
                cout << aux.second << " (Km. " << aux.first << ")" << endl;
                distGas.erase(it);
                origen = aux.first;
            }
        }
        restante = distancia - origen;
    }

    cout << "Hemos pasado por un total de " << contador << " paradas" << endl;
}

int main (int argc, char *argv[]){
    int destino = atoi(argv[2]);

    int autonomia;
    cout << "Autonomia del autobus: ";
    cin >> autonomia;
    cout << endl;

    if (!leerFichero(argv[1])){
        cout << "Lectura Incorrecta de fichero " << endl;
        return 1;
    }

    cout << "Gasolineras en las que nos hemos parado:" << endl;
    resolver(autonomia, destino);

}
