#include <iostream>
#include <fstream>
#include <stack>

using namespace std;

int **tablero, **M;
int fil, col;

void reservar(){
    tablero = new int*[fil];
    M = new int*[fil];
    for (int i = 0; i < fil; i++){
        tablero[i] = new int[col];
        M[i] = new int[col];
    }
    for (int i = 0; i < fil; i++){
        for (int j = 0; j < col; j++){
            M[i][j] = -1;
        }
    }
}

void liberar(){
    for (int i = 0; i < fil; i++){
        delete[] tablero[i];
        delete[] M[i];
    }
    delete[] tablero;
    delete[] M;
}


bool leerTablero(const char *nombrefich){
    ifstream fich;
    fich.open(nombrefich);
    if (!fich) return false;

    fich >> fil;
    fich >> col;
    reservar();

    for (int i = 0; i < fil; i++){
        for (int j = 0; j < col; j++){
            fich >> tablero[i][j];
        }
    }
}

void imprimirMatrices (){
    cout << "Tablero: " << endl;
    for (int i = 0; i < fil; i++){
        for (int j = 0; j < col; j++){
            cout << tablero[i][j] << "\t";
        }
        cout << endl;
    }
    cout << endl;

    cout << "Memoria: " << endl;
    for (int i = 0; i < fil; i++){
        for (int j = 0; j < col; j++){
            cout << M[i][j] << "\t";
        }
        cout << endl;
    }
    cout << endl;
}

void memoria(int i, int j, int acumulado){
    int casilla = acumulado + tablero[i][j];
    if (casilla > M[i][j]) M[i][j] = casilla;
    if (!(i == fil-1 && j == 0)){
        if (i==fil-1){
            if (M[i][j-1] != -1) memoria(i,j-1,casilla);
        } else if (j == 0){
            if (M[i+1][j] != -1) memoria(i+1,j,casilla);
        } else {
            if (tablero[i][j-1] != -1) memoria(i,j-1,casilla);
            if (tablero[i+1][j-1] != -1) memoria(i+1, j-1, casilla);
            if (tablero[i+1][j] != -1) memoria(i+1, j, casilla);
        }
    }
}

void recuperarSolucion(int i, int j, stack<pair<int,int>> & solucion){
    if (i!=0 || j!=col-1){
        pair <int,int> pos;
        pos.first = i;
        pos.second = j;
        solucion.push(pos);

        if (i == 0) {
            if (M[i][j+1] != -1) recuperarSolucion(i,j+1,solucion);
        }
        else if (j == col-1){
            if (M[i-1][j] != -1) recuperarSolucion(i-1,j,solucion);
        }
        else {
            int mayor = M[i-1][j+1];
            pos.first = i-1;
            pos.second = j+1;
            if (M[i-1][j] > mayor) {
                mayor = M[i-1][j];
                pos.first = i-1;
                pos.second = j;
            }
            if (M[i][j+1] > mayor) {
                mayor = M[i][j+1];
                pos.first = i;
                pos.second = j+1;
            }
            if (mayor != -1)
                recuperarSolucion(pos.first, pos.second, solucion);
        }
    } else {
        pair<int,int> inicio;
        inicio.first = 0;
        inicio.second = col-1;
        solucion.push(inicio);
    }
}


int main (int argc, char *argv[]){

    leerTablero(argv[1]);

    memoria(0,col-1,0);

    imprimirMatrices();

    stack<pair<int,int>> solucion;

    recuperarSolucion(fil-1, 0, solucion);

    if (solucion.size() == 1){
        cout << "No hay solución " << endl;
        return 1;
    }

    cout << "Recorrido Solucion: " << endl;

    while(!solucion.empty()){
        cout << "(" << solucion.top().first << "," << solucion.top().second << ")" << endl;
        solucion.pop();
    }

    liberar();
}
