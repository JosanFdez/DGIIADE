#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>


using namespace std;

int ** D;
int ** P;
int n, m;

string* idiomas;

map<double, int> solucion;

void reservar(int n){
    D = new int*[n];
    P = new int*[n];
    idiomas = new string[n];
    for (int i = 0; i < n; i++){
        D[i] = new int[n];
        P[i] = new int[n];
    }
}

void liberar(){
    for (int i = 0; i < n; i++){
        delete[] D[i];
        delete[] P[i];
    }
    delete[] D;
    delete[] P;
    delete[] idiomas;
}

void imprimirMatrices(){
    cout << "Matriz D: " << endl;
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            cout << D[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;

    cout << "Matriz P: " << endl;
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            cout << P[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

bool leerMatriz(const char *nombrefich){
    ifstream fich;

    fich.open(nombrefich);
    if (!fich) return false;

    // Leemos tamaño
    fich >> n;
    reservar(n);

    // Leemos idiomas
    pair<int, string> aux;
    string idioma;
    for (int i = 0; i < n; i++) {
        fich >> idioma;
        idiomas[i] = idioma;
    }

    // Leemos adyacencia
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            fich >> D[i][j];
        }
    }

    fich.close();
    return true;
}


void traduccion(int ** d, int ** p){
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            p[i][j] = 0;
        }
    }
    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (d[i][j] > d[i][k] + d[k][j]){
                    d[i][j] = d[i][k] + d[k][j];
                    p[i][j] = k;
                }
            }
        }
    }
}

void traza(int orig, int dest, int inf, int sup){
    int intermedio = P[orig][dest];
    if (intermedio != 0) {
        pair<double,int> aux;
        aux.first = (double(inf)+double(sup))/2;
        aux.second = intermedio;
        solucion.insert(aux);

        traza(orig, intermedio, inf, (inf+sup)/2);
        traza(intermedio, dest, (inf+sup)/2, sup);
    }
}

int main(int argc, char *argv[]) {
    leerMatriz(argv[1]);

    // Calculamos memoria
    traduccion(D,P);

    imprimirMatrices();

    string origen, destino;

    // Pedimos nodos origen y destino
    cout << "Idioma origen: ";
    cin >> origen;
    cout << "Idioma destino: ";
    cin >> destino;

    int orig, dest;
    bool foundorig = false, founddest = false;

    // Convertir de string a entero
    for (int i = 0; i < n || (!foundorig && !founddest); i++){
        if (idiomas[i] == origen) {
            foundorig = true;
            orig = i;
        }
        if (idiomas[i] == destino) {
            founddest = true;
            dest = i;
        }
    }

    if (!foundorig) {
        cout << "El idioma origen no existe" << endl;
        return 1;
    }

    if (!founddest) {
        cout << "El idioma destino no existe" << endl;
        return 1;
    }

    // Inicializamos conjunto solución
    m = D[orig][dest]+1;

    pair<double,int> aux;
    aux.first = 0;
    aux.second = orig;
    solucion.insert(aux);

    aux.first = m-1;
    aux.second = dest;
    solucion.insert(aux);

    // Recuperamos solución
    traza(orig, dest, 0, m-1);

    // Imprimimos resultados
    cout << "Hay que hacer " << m-1 << " traducciones" << endl;
    cout << "Traza: ";

    for (auto & it : solucion){
        cout << idiomas[it.second] << " -> ";
    }
    cout << endl;
    liberar();

}
